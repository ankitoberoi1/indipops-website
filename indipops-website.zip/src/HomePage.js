import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-white text-gray-900">
      <section className="text-center py-20 px-4">
        <h1 className="text-5xl font-bold mb-4">INDIPOPS</h1>
        <p className="text-lg max-w-xl mx-auto">
          Smart Snacking, Anytime. Anywhere.™ – Guilt-free Roasted Makhana crafted with heritage and innovation.
        </p>
        <Button className="mt-6 text-lg px-8 py-4">Shop Now</Button>
      </section>

      <section className="bg-white py-16 px-6">
        <h2 className="text-3xl font-semibold text-center mb-10">Our Story</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 max-w-6xl mx-auto">
          <Card><CardContent className="text-center p-4"><img src="/images/harvest.png" alt="Harvest" className="mx-auto mb-4" /><h3 className="font-bold text-xl mb-2">Hand-Harvested</h3><p>From the pristine ponds of Bihar, our seeds are ethically hand-harvested by expert local farmers.</p></CardContent></Card>
          <Card><CardContent className="text-center p-4"><img src="/images/roast.png" alt="Roasting" className="mx-auto mb-4" /><h3 className="font-bold text-xl mb-2">Traditional Roasting</h3><p>Seeds are sun-dried and roasted the traditional way over firewood pans to lock in nutrition.</p></CardContent></Card>
          <Card><CardContent className="text-center p-4"><img src="/images/pitna.png" alt="Pitna" className="mx-auto mb-4" /><h3 className="font-bold text-xl mb-2">Popped with a Pitna</h3><p>An artisan’s precision with a Pitna tool ensures each seed is perfectly popped – no compromise.</p></CardContent></Card>
          <Card><CardContent className="text-center p-4"><img src="/images/flavour.png" alt="Flavor" className="mx-auto mb-4" /><h3 className="font-bold text-xl mb-2">Flavour Curation</h3><p>Blended with bold Indian & global flavours, INDIPOPS offers snacks that delight every palate.</p></CardContent></Card>
        </div>
      </section>

      <section className="bg-amber-100 py-20 px-4 text-center">
        <h2 className="text-3xl font-semibold mb-4">A Global Snack Sensation</h2>
        <p className="max-w-2xl mx-auto mb-8">Whether you're in New York, Tokyo, London or Mumbai – INDIPOPS is your travel buddy, desk snack, or fitness fuel.</p>
        <Button className="text-lg px-6 py-3">Order Internationally</Button>
      </section>

      <section className="py-20 px-6 bg-white text-center">
        <h2 className="text-3xl font-bold mb-10">Shop Our Flavours</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 max-w-6xl mx-auto">
          <Card><CardContent className="p-6"><img src="/images/classic-salted.png" alt="Classic Salted" className="w-full mb-4 rounded-xl" /><h3 className="text-xl font-semibold">Classic Salted</h3><p className="text-sm my-2">Timeless, light and healthy.</p><Button className="mt-3 w-full">Buy Now</Button></CardContent></Card>
          <Card><CardContent className="p-6"><img src="/images/peri-peri.png" alt="Peri Peri" className="w-full mb-4 rounded-xl" /><h3 className="text-xl font-semibold">Peri Peri</h3><p className="text-sm my-2">Hot, zesty, and bold.</p><Button className="mt-3 w-full">Buy Now</Button></CardContent></Card>
          <Card><CardContent className="p-6"><img src="/images/tandoori-masala.png" alt="Tandoori Masala" className="w-full mb-4 rounded-xl" /><h3 className="text-xl font-semibold">Tandoori Masala</h3><p className="text-sm my-2">Smoky & spicy Indian touch.</p><Button className="mt-3 w-full">Buy Now</Button></CardContent></Card>
        </div>
      </section>

      <footer className="bg-gray-800 text-white py-10 px-4 text-center">
        <p className="mb-2">© 2025 INDIPOPS – All Rights Reserved</p>
        <p className="text-sm">Crafted with ❤️ in India | <a href="mailto:info@indipops.in" className="underline">info@indipops.in</a></p>
      </footer>
    </main>
  );
}