export function Button({ children, className }) {
  return <button className={`bg-orange-500 text-white rounded-xl ${className}`}>{children}</button>;
}